# UTS Dasar Komputer dan Pemrograman - Kelompok B (Telekomunikasi)
# Monitoring Kualitas Sinyal / SNR
#
# Aturan status:
#   SNR < 10 dB        -> RENDAH
#   10 <= SNR < 20 dB  -> BAIK
#   SNR >= 20 dB       -> SANGAT BAIK

BATAS_BAIK = 10         # dB, batas bawah kategori BAIK
BATAS_SANGAT_BAIK = 20  # dB, batas bawah kategori SANGAT BAIK

DAFTAR_KATEGORI = ["RENDAH", "BAIK", "SANGAT BAIK"]

# 15 data inti dari soal (dB)
data_inti = [5, 8, 11, 14, 18, 22, 27, 9, 16, 24, 12, 30, 7, 20, 15]

# 5 data tambahan (dB) untuk menguji batas kategori dan variasi nilai
data_tambahan = [10, 19, 3, 38, 9.5]

# Total 20 data yang diproses
data_snr = data_inti + data_tambahan


def kualitas_sinyal(snr):
    """Menentukan kategori kualitas sinyal dari nilai SNR (dB)."""
    if snr < BATAS_BAIK:
        return "RENDAH"
    elif snr < BATAS_SANGAT_BAIK:
        return "BAIK"
    else:
        return "SANGAT BAIK"


def hitung_kategori(data):
    """Menghitung jumlah data pada setiap kategori. Return: dictionary."""
    jumlah = {}
    for kategori in DAFTAR_KATEGORI:
        jumlah[kategori] = 0
    for snr in data:
        status = kualitas_sinyal(snr)
        jumlah[status] = jumlah[status] + 1
    return jumlah


def rata_rata(data):
    """Menghitung nilai rata-rata dari list angka."""
    total = 0
    for nilai in data:
        total = total + nilai
    return total / len(data)


def tampilkan_monitoring(data):
    """Menampilkan nomor, nilai SNR, dan status untuk setiap data."""
    print("========== MONITORING KUALITAS SINYAL ==========")
    for nomor, snr in enumerate(data, start=1):
        status = kualitas_sinyal(snr)
        print(f"{nomor:02d}  SNR = {snr:>4} dB  ->  {status}")


def tampilkan_ringkasan(data):
    """Menampilkan total data, jumlah per kategori, rata-rata, maks, dan min."""
    jumlah = hitung_kategori(data)
    print()
    print("================== RINGKASAN ===================")
    print(f"Total data       : {len(data)}")
    for kategori in DAFTAR_KATEGORI:
        print(f"{kategori:<17}: {jumlah[kategori]}")
    print(f"Rata-rata SNR    : {rata_rata(data):.2f} dB")
    print(f"Maksimum SNR     : {max(data)} dB")
    print(f"Minimum SNR      : {min(data)} dB")


def jalankan_pengujian():
    """Menguji kualitas_sinyal() pada kedua batas kategori serta nilai rendah/tinggi."""
    test_case = [
        (9, "RENDAH"),        # sedikit di bawah batas 10
        (10, "BAIK"),         # tepat pada batas 10
        (11, "BAIK"),         # sedikit di atas batas 10
        (19, "BAIK"),         # sedikit di bawah batas 20
        (20, "SANGAT BAIK"),  # tepat pada batas 20
        (21, "SANGAT BAIK"),  # sedikit di atas batas 20
        (2, "RENDAH"),        # nilai rendah realistis
        (40, "SANGAT BAIK"),  # nilai tinggi realistis
    ]
    print()
    print("=================== PENGUJIAN ==================")
    print(f"{'No':<4}{'Input':<10}{'Expected':<14}{'Actual':<14}Hasil")
    jumlah_pass = 0
    for nomor, (snr, expected) in enumerate(test_case, start=1):
        actual = kualitas_sinyal(snr)
        if actual == expected:
            hasil = "PASS"
            jumlah_pass = jumlah_pass + 1
        else:
            hasil = "FAIL"
        print(f"{nomor:<4}{str(snr) + ' dB':<10}{expected:<14}{actual:<14}{hasil}")
    print(f"Hasil: {jumlah_pass}/{len(test_case)} test PASS")


tampilkan_monitoring(data_snr)
tampilkan_ringkasan(data_snr)
jalankan_pengujian()
